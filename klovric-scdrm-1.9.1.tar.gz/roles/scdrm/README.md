This role is core of SCDRM.
It will install/remove/update SCDRM stack.
