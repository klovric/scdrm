This role is part of SCDRM.
It will install and configure AIDE.
