This role is part of SCDRM.
It will install script/tlog
