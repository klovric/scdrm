This role is part of SCDRM.
It will get kernel version of a system.
