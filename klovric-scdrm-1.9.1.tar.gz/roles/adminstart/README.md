This role is part of SCDRM.
It will enter the system into 'adminmode' and prepare it for being changed.
