This role is part of SCDRM.
It will exit the system from 'adminmode' and commit the changes.
